
  # Anonymous Reporting Program

  This is a code bundle for Anonymous Reporting Program. The original project is available at https://www.figma.com/design/0bjICEXVKtUH7qmjrcoE3S/Anonymous-Reporting-Program.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  