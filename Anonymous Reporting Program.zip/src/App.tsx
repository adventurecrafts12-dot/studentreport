import { useState, useEffect } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { StudentCodeEntry } from './components/StudentCodeEntry';
import { StudentMenu } from './components/StudentMenu';
import { NewCaseForm } from './components/NewCaseForm';
import { CaseSubmitted } from './components/CaseSubmitted';
import { CurrentCaseView } from './components/CurrentCaseView';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';

export interface Case {
  id: string;
  caseNumber: string;
  anonymous: boolean;
  studentName?: string;
  issue: string;
  actionRequested: string;
  status: 'open' | 'closed' | 'requested-to-close';
  messages: Message[];
  createdAt: string;
}

export interface Message {
  id: string;
  sender: 'student' | 'admin';
  text: string;
  timestamp: string;
}

export interface TeacherAccount {
  id: string;
  username: string;
  password: string;
  createdAt: string;
}

type Screen = 
  | { type: 'welcome' }
  | { type: 'student-code' }
  | { type: 'student-menu' }
  | { type: 'new-case' }
  | { type: 'case-submitted', caseNumber: string }
  | { type: 'current-case', caseNumber: string }
  | { type: 'admin-login' }
  | { type: 'admin-dashboard' };

function App() {
  const [screen, setScreen] = useState<Screen>({ type: 'welcome' });
  const [cases, setCases] = useState<Case[]>([]);
  const [teacherAccounts, setTeacherAccounts] = useState<TeacherAccount[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);

  // Load cases from localStorage on mount
  useEffect(() => {
    // Clear all cases - starting fresh
    localStorage.removeItem('linkCases');
    setCases([]);
  }, []);

  // Load teacher accounts from localStorage
  useEffect(() => {
    const savedAccounts = localStorage.getItem('linkTeacherAccounts');
    if (savedAccounts) {
      setTeacherAccounts(JSON.parse(savedAccounts));
    }
  }, []);

  // Save cases to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('linkCases', JSON.stringify(cases));
  }, [cases]);

  // Save teacher accounts to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('linkTeacherAccounts', JSON.stringify(teacherAccounts));
  }, [teacherAccounts]);

  const handleWelcomeChoice = (choice: 'student' | 'teacher') => {
    if (choice === 'student') {
      setScreen({ type: 'student-code' });
    } else {
      setScreen({ type: 'admin-login' });
    }
  };

  const handleCodeSuccess = () => {
    setScreen({ type: 'student-menu' });
  };

  const handleMenuChoice = (choice: 'new' | 'current') => {
    if (choice === 'new') {
      setScreen({ type: 'new-case' });
    } else {
      // For current case, we'll prompt for case number in CurrentCaseView
      setScreen({ type: 'current-case', caseNumber: '' });
    }
  };

  const handleCaseSubmit = (caseData: Omit<Case, 'id' | 'caseNumber' | 'status' | 'messages' | 'createdAt'>) => {
    const caseNumber = generateCaseNumber();
    const newCase: Case = {
      ...caseData,
      id: Date.now().toString(),
      caseNumber,
      status: 'open',
      messages: [],
      createdAt: new Date().toISOString(),
    };
    setCases([...cases, newCase]);
    setScreen({ type: 'case-submitted', caseNumber });
  };

  const generateCaseNumber = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  const handleBackToMenu = () => {
    setScreen({ type: 'student-menu' });
  };

  const handleBackToWelcome = () => {
    setScreen({ type: 'welcome' });
  };

  const handleAdminLogin = () => {
    setScreen({ type: 'admin-dashboard' });
    setIsAdmin(true);
  };

  const handleTeacherLogin = () => {
    setScreen({ type: 'admin-dashboard' });
    setIsAdmin(false);
  };

  const handleCreateTeacherAccount = (username: string, password: string) => {
    const newAccount: TeacherAccount = {
      id: Date.now().toString(),
      username,
      password,
      createdAt: new Date().toISOString(),
    };
    setTeacherAccounts([...teacherAccounts, newAccount]);
  };

  const handleDeleteTeacherAccount = (id: string) => {
    setTeacherAccounts(teacherAccounts.filter(account => account.id !== id));
  };

  const handleViewCase = (caseNumber: string) => {
    setScreen({ type: 'current-case', caseNumber });
  };

  const handleSendMessage = (caseNumber: string, text: string, sender: 'student' | 'admin') => {
    setCases(cases.map(c => {
      if (c.caseNumber === caseNumber) {
        return {
          ...c,
          messages: [
            ...c.messages,
            {
              id: Date.now().toString(),
              sender,
              text,
              timestamp: new Date().toISOString(),
            },
          ],
        };
      }
      return c;
    }));
  };

  const handleUpdateCaseStatus = (caseNumber: string, status: Case['status']) => {
    setCases(cases.map(c => {
      if (c.caseNumber === caseNumber) {
        return { ...c, status };
      }
      return c;
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {screen.type === 'welcome' && (
        <WelcomeScreen onChoice={handleWelcomeChoice} />
      )}
      {screen.type === 'student-code' && (
        <StudentCodeEntry onSuccess={handleCodeSuccess} onBack={handleBackToWelcome} />
      )}
      {screen.type === 'student-menu' && (
        <StudentMenu onChoice={handleMenuChoice} onBack={handleBackToWelcome} />
      )}
      {screen.type === 'new-case' && (
        <NewCaseForm onSubmit={handleCaseSubmit} onBack={handleBackToMenu} />
      )}
      {screen.type === 'case-submitted' && (
        <CaseSubmitted caseNumber={screen.caseNumber} onBack={handleBackToMenu} />
      )}
      {screen.type === 'current-case' && (
        <CurrentCaseView
          caseNumber={screen.caseNumber}
          cases={cases}
          onSendMessage={handleSendMessage}
          onUpdateStatus={handleUpdateCaseStatus}
          onBack={handleBackToMenu}
        />
      )}
      {screen.type === 'admin-login' && (
        <AdminLogin 
          onAdminLogin={handleAdminLogin} 
          onTeacherLogin={handleTeacherLogin}
          teacherAccounts={teacherAccounts}
          onBack={handleBackToWelcome} 
        />
      )}
      {screen.type === 'admin-dashboard' && (
        <AdminDashboard
          cases={cases}
          isAdmin={isAdmin}
          teacherAccounts={teacherAccounts}
          onCreateTeacherAccount={handleCreateTeacherAccount}
          onDeleteTeacherAccount={handleDeleteTeacherAccount}
          onViewCase={handleViewCase}
          onSendMessage={handleSendMessage}
          onUpdateStatus={handleUpdateCaseStatus}
          onBack={handleBackToWelcome}
        />
      )}
    </div>
  );
}

export default App;