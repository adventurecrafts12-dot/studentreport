import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import type { Case } from '../App';

interface NewCaseFormProps {
  onSubmit: (caseData: Omit<Case, 'id' | 'caseNumber' | 'status' | 'messages' | 'createdAt'>) => void;
  onBack: () => void;
}

export function NewCaseForm({ onSubmit, onBack }: NewCaseFormProps) {
  const [anonymous, setAnonymous] = useState<boolean | null>(null);
  const [studentName, setStudentName] = useState('');
  const [issue, setIssue] = useState('');
  const [actionRequested, setActionRequested] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    onSubmit({
      anonymous: anonymous === true,
      studentName: anonymous === false ? studentName : undefined,
      issue,
      actionRequested,
    });
  };

  const canSubmit = anonymous !== null && issue.trim() !== '' && actionRequested.trim() !== '' && 
    (anonymous === true || (anonymous === false && studentName.trim() !== ''));

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-2xl w-full">
        <button
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-center text-gray-900 mb-2">Open a New Case</h2>
          <p className="text-center text-gray-600 mb-8">
            We're here to help. Please provide details about your concern.
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Anonymous Question */}
            <div>
              <label className="block text-gray-900 mb-3">
                Would you like to report this anonymously?
              </label>
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setAnonymous(true)}
                  className={`flex-1 py-3 rounded-lg border-2 transition-all ${
                    anonymous === true
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                      : 'border-gray-300 text-gray-700 hover:border-gray-400'
                  }`}
                >
                  Yes, Anonymous
                </button>
                <button
                  type="button"
                  onClick={() => setAnonymous(false)}
                  className={`flex-1 py-3 rounded-lg border-2 transition-all ${
                    anonymous === false
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                      : 'border-gray-300 text-gray-700 hover:border-gray-400'
                  }`}
                >
                  No, Include My Name
                </button>
              </div>
            </div>

            {/* Name Field (only if not anonymous) */}
            {anonymous === false && (
              <div>
                <label className="block text-gray-900 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required={anonymous === false}
                />
              </div>
            )}

            {/* Issue Field */}
            <div>
              <label className="block text-gray-900 mb-2">
                What is the issue?
              </label>
              <textarea
                value={issue}
                onChange={(e) => setIssue(e.target.value)}
                placeholder="Describe the issue in detail..."
                rows={5}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                required
              />
            </div>

            {/* Action Requested Field */}
            <div>
              <label className="block text-gray-900 mb-2">
                What would you like done?
              </label>
              <textarea
                value={actionRequested}
                onChange={(e) => setActionRequested(e.target.value)}
                placeholder="What action would you like administration to take..."
                rows={3}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                required
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={!canSubmit}
              className="w-full bg-green-600 text-white py-4 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Open Case
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
