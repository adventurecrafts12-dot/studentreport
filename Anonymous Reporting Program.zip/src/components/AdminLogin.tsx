import { useState } from 'react';
import { ArrowLeft, Shield } from 'lucide-react';
import type { TeacherAccount } from '../App';

interface AdminLoginProps {
  onAdminLogin: () => void;
  onTeacherLogin: () => void;
  teacherAccounts: TeacherAccount[];
  onBack: () => void;
}

const ADMIN_USERNAME = 'lcadmindemo1';
const ADMIN_PASSWORD = '@1DEMOlcP';

export function AdminLogin({ onAdminLogin, onTeacherLogin, teacherAccounts, onBack }: AdminLoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if admin
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      onAdminLogin();
      return;
    }
    
    // Check if teacher account
    const teacherAccount = teacherAccounts.find(
      account => account.username === username && account.password === password
    );
    
    if (teacherAccount) {
      onTeacherLogin();
      return;
    }
    
    // Invalid credentials
    setError(true);
    setTimeout(() => setError(false), 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        <button
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <Shield className="w-8 h-8 text-green-600" />
            </div>
          </div>

          <h2 className="text-center text-gray-900 mb-2">Administration Login</h2>
          <p className="text-center text-gray-600 mb-6">
            Enter your credentials to access the dashboard
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-gray-900 mb-2">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username"
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div>
              <label className="block text-gray-900 mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            {error && (
              <p className="text-red-600 text-sm">Incorrect username or password. Please try again.</p>
            )}

            <button
              type="submit"
              className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors"
            >
              Login
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
