import { CheckCircle } from 'lucide-react';

interface CaseSubmittedProps {
  caseNumber: string;
  onBack: () => void;
}

export function CaseSubmitted({ caseNumber, onBack }: CaseSubmittedProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
          </div>

          <h2 className="text-gray-900 mb-2">You Did the Right Thing</h2>
          
          <p className="text-gray-600 mb-6">
            Your case has been submitted to administration. They will review it and get back to you.
          </p>

          <div className="bg-indigo-50 border-2 border-indigo-200 rounded-lg p-6 mb-8">
            <p className="text-gray-700 mb-2">Your case number is:</p>
            <p className="text-indigo-900 tracking-wider">{caseNumber}</p>
            <p className="text-gray-600 text-sm mt-4">
              Save this number to check your case status and message administration.
            </p>
          </div>

          <button
            onClick={onBack}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Back to Menu
          </button>
        </div>
      </div>
    </div>
  );
}
