import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Send, MessageSquare, X, UserPlus, Users } from 'lucide-react';
import type { Case, TeacherAccount } from '../App';

interface AdminDashboardProps {
  cases: Case[];
  isAdmin: boolean;
  teacherAccounts: TeacherAccount[];
  onCreateTeacherAccount: (username: string, password: string) => void;
  onDeleteTeacherAccount: (id: string) => void;
  onViewCase: (caseNumber: string) => void;
  onSendMessage: (caseNumber: string, text: string, sender: 'student' | 'admin') => void;
  onUpdateStatus: (caseNumber: string, status: Case['status']) => void;
  onBack: () => void;
}

export function AdminDashboard({ 
  cases, 
  isAdmin,
  teacherAccounts,
  onCreateTeacherAccount,
  onDeleteTeacherAccount,
  onSendMessage, 
  onUpdateStatus, 
  onBack 
}: AdminDashboardProps) {
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);
  const [messageText, setMessageText] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'open' | 'closed' | 'requested-to-close'>('all');
  const [showAccountManagement, setShowAccountManagement] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [createError, setCreateError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedCase?.messages]);

  // Update selected case when cases change
  useEffect(() => {
    if (selectedCase) {
      const updated = cases.find(c => c.caseNumber === selectedCase.caseNumber);
      if (updated) {
        setSelectedCase(updated);
      }
    }
  }, [cases, selectedCase]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageText.trim() && selectedCase) {
      onSendMessage(selectedCase.caseNumber, messageText, 'admin');
      setMessageText('');
    }
  };

  const handleCloseCase = () => {
    if (selectedCase) {
      onUpdateStatus(selectedCase.caseNumber, 'closed');
    }
  };

  const handleReopenCase = () => {
    if (selectedCase) {
      onUpdateStatus(selectedCase.caseNumber, 'open');
    }
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate
    if (newUsername.trim().length < 3) {
      setCreateError('Username must be at least 3 characters');
      return;
    }
    
    if (newPassword.trim().length < 6) {
      setCreateError('Password must be at least 6 characters');
      return;
    }
    
    // Check if username already exists
    if (teacherAccounts.some(account => account.username === newUsername)) {
      setCreateError('Username already exists');
      return;
    }
    
    // Check against admin username
    if (newUsername === 'lcadmindemo1') {
      setCreateError('This username is reserved');
      return;
    }
    
    onCreateTeacherAccount(newUsername, newPassword);
    setNewUsername('');
    setNewPassword('');
    setCreateError('');
    setShowCreateForm(false);
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const getStatusColor = (status: Case['status']) => {
    switch (status) {
      case 'open':
        return 'bg-green-100 text-green-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      case 'requested-to-close':
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getStatusText = (status: Case['status']) => {
    switch (status) {
      case 'open':
        return 'Open';
      case 'closed':
        return 'Closed';
      case 'requested-to-close':
        return 'Requested to Close';
    }
  };

  const filteredCases = filterStatus === 'all' 
    ? cases 
    : cases.filter(c => c.status === filterStatus);

  const sortedCases = [...filteredCases].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Logout
          </button>
          <div className="flex items-center gap-4">
            <h1 className="text-gray-900">{isAdmin ? 'Admin' : 'Teacher'} Dashboard</h1>
            {isAdmin && (
              <button
                onClick={() => setShowAccountManagement(!showAccountManagement)}
                className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
              >
                <Users className="w-5 h-5" />
                Manage Accounts
              </button>
            )}
          </div>
        </div>

        {/* Coming Soon Banner for Teachers */}
        {!isAdmin && (
          <div className="mb-6 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-2xl shadow-xl p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                  <MessageSquare className="w-6 h-6" />
                </div>
              </div>
              <div className="flex-1">
                <h3 className="mb-2">Coming Soon: Proton Video Meetings</h3>
                <p className="text-indigo-100">
                  A new feature is coming soon where you can meet via Proton through the software with students directly from their cases. Stay tuned for secure, private video conferencing integrated right into LINK.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Account Management Modal */}
        {isAdmin && showAccountManagement && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-6 z-50">
            <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-center">
                <h2 className="text-gray-900">Teacher Account Management</h2>
                <button
                  onClick={() => {
                    setShowAccountManagement(false);
                    setShowCreateForm(false);
                    setCreateError('');
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-6">
                {/* Create Account Form */}
                {!showCreateForm ? (
                  <button
                    onClick={() => setShowCreateForm(true)}
                    className="w-full mb-6 flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <UserPlus className="w-5 h-5" />
                    Create New Teacher Account
                  </button>
                ) : (
                  <div className="mb-6 p-6 border-2 border-green-200 rounded-lg bg-green-50">
                    <h3 className="text-gray-900 mb-4">Create New Teacher Account</h3>
                    <form onSubmit={handleCreateAccount} className="space-y-4">
                      <div>
                        <label className="block text-gray-900 mb-2">Username</label>
                        <input
                          type="text"
                          value={newUsername}
                          onChange={(e) => setNewUsername(e.target.value)}
                          placeholder="Enter username"
                          className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-900 mb-2">Password</label>
                        <input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Enter password"
                          className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                      </div>
                      {createError && (
                        <p className="text-red-600 text-sm">{createError}</p>
                      )}
                      <div className="flex gap-3">
                        <button
                          type="submit"
                          className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors"
                        >
                          Create Account
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowCreateForm(false);
                            setCreateError('');
                            setNewUsername('');
                            setNewPassword('');
                          }}
                          className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                {/* Teacher Accounts List */}
                <h3 className="text-gray-900 mb-4">Teacher Accounts ({teacherAccounts.length})</h3>
                {teacherAccounts.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No teacher accounts created yet</p>
                ) : (
                  <div className="space-y-3">
                    {teacherAccounts.map((account) => (
                      <div
                        key={account.id}
                        className="p-4 border-2 border-gray-200 rounded-lg flex justify-between items-center"
                      >
                        <div>
                          <p className="text-gray-900">{account.username}</p>
                          <p className="text-gray-500 text-sm">
                            Created {new Date(account.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            if (confirm(`Delete teacher account "${account.username}"?`)) {
                              onDeleteTeacherAccount(account.id);
                            }
                          }}
                          className="text-red-600 hover:text-red-700 px-4 py-2 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          Delete
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-5 gap-6">
          {/* Cases List */}
          <div className="lg:col-span-2 bg-white rounded-2xl shadow-xl p-6">
            <div className="mb-4">
              <h2 className="text-gray-900 mb-4">All Cases ({cases.length})</h2>
              
              {/* Filter Buttons */}
              <div className="flex gap-2 flex-wrap mb-4">
                <button
                  onClick={() => setFilterStatus('all')}
                  className={`px-3 py-1 rounded-full text-sm transition-colors ${
                    filterStatus === 'all'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilterStatus('open')}
                  className={`px-3 py-1 rounded-full text-sm transition-colors ${
                    filterStatus === 'open'
                      ? 'bg-green-600 text-white'
                      : 'bg-green-100 text-green-800 hover:bg-green-200'
                  }`}
                >
                  Open
                </button>
                <button
                  onClick={() => setFilterStatus('requested-to-close')}
                  className={`px-3 py-1 rounded-full text-sm transition-colors ${
                    filterStatus === 'requested-to-close'
                      ? 'bg-yellow-600 text-white'
                      : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
                  }`}
                >
                  Requested
                </button>
                <button
                  onClick={() => setFilterStatus('closed')}
                  className={`px-3 py-1 rounded-full text-sm transition-colors ${
                    filterStatus === 'closed'
                      ? 'bg-gray-600 text-white'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  Closed
                </button>
              </div>
            </div>

            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {sortedCases.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No cases to display</p>
              ) : (
                sortedCases.map((caseItem) => (
                  <button
                    key={caseItem.id}
                    onClick={() => setSelectedCase(caseItem)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                      selectedCase?.id === caseItem.id
                        ? 'border-indigo-500 bg-indigo-50'
                        : 'border-gray-200 hover:border-gray-300 bg-white'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-gray-900">#{caseItem.caseNumber}</span>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(caseItem.status)}`}>
                        {getStatusText(caseItem.status)}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm line-clamp-2 mb-2">
                      {caseItem.issue}
                    </p>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span>{new Date(caseItem.createdAt).toLocaleDateString()}</span>
                      {caseItem.messages.length > 0 && (
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-3 h-3" />
                          {caseItem.messages.length}
                        </span>
                      )}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Case Details */}
          <div className="lg:col-span-3">
            {selectedCase ? (
              <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
                {/* Case Header */}
                <div className="bg-green-600 text-white p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h2>Case #{selectedCase.caseNumber}</h2>
                        <button
                          onClick={() => setSelectedCase(null)}
                          className="lg:hidden p-1 hover:bg-green-700 rounded"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                      <p className="opacity-90 text-sm">
                        Submitted {new Date(selectedCase.createdAt).toLocaleDateString()} at{' '}
                        {new Date(selectedCase.createdAt).toLocaleTimeString()}
                      </p>
                      {!selectedCase.anonymous && selectedCase.studentName && (
                        <p className="opacity-90 text-sm mt-1">Student: {selectedCase.studentName}</p>
                      )}
                      {selectedCase.anonymous && (
                        <p className="opacity-90 text-sm mt-1">Anonymous Report</p>
                      )}
                    </div>
                    <span className={`px-4 py-2 rounded-full text-sm ${getStatusColor(selectedCase.status)} border-2 border-white`}>
                      {getStatusText(selectedCase.status)}
                    </span>
                  </div>
                </div>

                {/* Case Details */}
                <div className="p-6 border-b border-gray-200">
                  <div className="space-y-4">
                    <div>
                      <p className="text-gray-900 mb-1">Issue:</p>
                      <p className="text-gray-700">{selectedCase.issue}</p>
                    </div>
                    <div>
                      <p className="text-gray-900 mb-1">Action Requested:</p>
                      <p className="text-gray-700">{selectedCase.actionRequested}</p>
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <div className="p-6 bg-gray-50 min-h-[300px] max-h-[400px] overflow-y-auto">
                  <h3 className="text-gray-900 mb-4">Messages</h3>
                  {selectedCase.messages.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">
                      No messages yet. Send a message to the student.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {selectedCase.messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender === 'admin' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[70%] rounded-lg p-4 ${
                              message.sender === 'admin'
                                ? 'bg-green-600 text-white'
                                : 'bg-white text-gray-900 border border-gray-200'
                            }`}
                          >
                            <p className="text-xs mb-2 opacity-75">
                              {message.sender === 'admin' ? 'You' : 'Student'}
                            </p>
                            <p className="mb-1">{message.text}</p>
                            <p className={`text-xs ${message.sender === 'admin' ? 'text-green-200' : 'text-gray-500'}`}>
                              {formatTimestamp(message.timestamp)}
                            </p>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </div>

                {/* Message Input & Actions */}
                <div className="p-6 border-t border-gray-200">
                  <form onSubmit={handleSendMessage} className="flex gap-3 mb-4">
                    <input
                      type="text"
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder="Type a message to the student..."
                      className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                    <button
                      type="submit"
                      disabled={!messageText.trim()}
                      className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </form>

                  <div className="flex gap-3">
                    {selectedCase.status !== 'closed' ? (
                      <button
                        onClick={handleCloseCase}
                        className="flex-1 bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-700 transition-colors"
                      >
                        Close Case
                      </button>
                    ) : (
                      <button
                        onClick={handleReopenCase}
                        className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors"
                      >
                        Reopen Case
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                    <MessageSquare className="w-8 h-8 text-gray-400" />
                  </div>
                </div>
                <h3 className="text-gray-900 mb-2">No Case Selected</h3>
                <p className="text-gray-600">Select a case from the list to view details and communicate with the student.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}