import { GraduationCap, Shield } from 'lucide-react';

interface WelcomeScreenProps {
  onChoice: (choice: 'student' | 'teacher') => void;
}

export function WelcomeScreen({ onChoice }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-indigo-900 mb-4">LINK</h1>
          <p className="text-gray-600 text-xl">Lead Issues to Necessary Knowledge</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <button
            onClick={() => onChoice('student')}
            className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all hover:scale-105 group"
          >
            <div className="flex flex-col items-center gap-4">
              <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center group-hover:bg-indigo-200 transition-colors">
                <GraduationCap className="w-10 h-10 text-indigo-600" />
              </div>
              <span className="text-gray-900">Student Side</span>
            </div>
          </button>

          <button
            onClick={() => onChoice('teacher')}
            className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all hover:scale-105 group"
          >
            <div className="flex flex-col items-center gap-4">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <Shield className="w-10 h-10 text-green-600" />
              </div>
              <span className="text-gray-900">Teacher Side</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
