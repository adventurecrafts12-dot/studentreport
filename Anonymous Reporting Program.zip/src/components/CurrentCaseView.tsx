import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Send, AlertCircle } from 'lucide-react';
import type { Case } from '../App';

interface CurrentCaseViewProps {
  caseNumber: string;
  cases: Case[];
  onSendMessage: (caseNumber: string, text: string, sender: 'student' | 'admin') => void;
  onUpdateStatus: (caseNumber: string, status: Case['status']) => void;
  onBack: () => void;
}

export function CurrentCaseView({ caseNumber: initialCaseNumber, cases, onSendMessage, onUpdateStatus, onBack }: CurrentCaseViewProps) {
  const [caseNumber, setCaseNumber] = useState(initialCaseNumber);
  const [enteredNumber, setEnteredNumber] = useState('');
  const [messageText, setMessageText] = useState('');
  const [showCaseNotFound, setShowCaseNotFound] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentCase = cases.find(c => c.caseNumber === caseNumber);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentCase?.messages]);

  const handleLookupCase = (e: React.FormEvent) => {
    e.preventDefault();
    const foundCase = cases.find(c => c.caseNumber === enteredNumber);
    if (foundCase) {
      setCaseNumber(enteredNumber);
      setShowCaseNotFound(false);
    } else {
      setShowCaseNotFound(true);
      setTimeout(() => setShowCaseNotFound(false), 3000);
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageText.trim() && currentCase) {
      onSendMessage(currentCase.caseNumber, messageText, 'student');
      setMessageText('');
    }
  };

  const handleRequestClose = () => {
    if (currentCase) {
      onUpdateStatus(currentCase.caseNumber, 'requested-to-close');
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const getStatusColor = (status: Case['status']) => {
    switch (status) {
      case 'open':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'requested-to-close':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  const getStatusText = (status: Case['status']) => {
    switch (status) {
      case 'open':
        return 'Open';
      case 'closed':
        return 'Closed';
      case 'requested-to-close':
        return 'Requested to Close';
    }
  };

  if (!currentCase) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-md w-full">
          <button
            onClick={onBack}
            className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-center text-gray-900 mb-2">View Current Case</h2>
            <p className="text-center text-gray-600 mb-6">
              Enter your 6-digit case number
            </p>

            <form onSubmit={handleLookupCase} className="space-y-4">
              <div>
                <input
                  type="text"
                  value={enteredNumber}
                  onChange={(e) => setEnteredNumber(e.target.value)}
                  placeholder="Enter case number"
                  maxLength={6}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-center tracking-wider ${
                    showCaseNotFound ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {showCaseNotFound && (
                  <div className="mt-3 flex items-center gap-2 text-red-600 text-sm">
                    <AlertCircle className="w-4 h-4" />
                    <span>Case not found. Please check the number and try again.</span>
                  </div>
                )}
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                View Case
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Menu
        </button>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Case Header */}
          <div className="bg-indigo-600 text-white p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="mb-1">Case #{currentCase.caseNumber}</h2>
                <p className="opacity-90 text-sm">Submitted {new Date(currentCase.createdAt).toLocaleDateString()}</p>
              </div>
              <span className={`px-4 py-2 rounded-full border-2 ${getStatusColor(currentCase.status)}`}>
                {getStatusText(currentCase.status)}
              </span>
            </div>
          </div>

          {/* Case Details */}
          <div className="p-6 border-b border-gray-200">
            <div className="space-y-4">
              <div>
                <p className="text-gray-900 mb-1">Issue:</p>
                <p className="text-gray-700">{currentCase.issue}</p>
              </div>
              <div>
                <p className="text-gray-900 mb-1">Action Requested:</p>
                <p className="text-gray-700">{currentCase.actionRequested}</p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="p-6 bg-gray-50 min-h-[300px] max-h-[400px] overflow-y-auto">
            <h3 className="text-gray-900 mb-4">Messages</h3>
            {currentCase.messages.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                No messages yet. Administration will respond soon.
              </p>
            ) : (
              <div className="space-y-4">
                {currentCase.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'student' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[70%] rounded-lg p-4 ${
                        message.sender === 'student'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-white text-gray-900 border border-gray-200'
                      }`}
                    >
                      <p className="mb-1">{message.text}</p>
                      <p className={`text-xs ${message.sender === 'student' ? 'text-indigo-200' : 'text-gray-500'}`}>
                        {formatTimestamp(message.timestamp)}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          {/* Message Input */}
          {currentCase.status !== 'closed' && (
            <div className="p-6 border-t border-gray-200">
              <form onSubmit={handleSendMessage} className="flex gap-3 mb-4">
                <input
                  type="text"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Type a message to administration..."
                  className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  disabled={!messageText.trim()}
                  className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>

              {currentCase.status === 'open' && (
                <button
                  onClick={handleRequestClose}
                  className="w-full text-gray-600 hover:text-gray-900 py-2 text-sm"
                >
                  Request to Close Case
                </button>
              )}
            </div>
          )}

          {currentCase.status === 'closed' && (
            <div className="p-6 bg-gray-100 text-center">
              <p className="text-gray-700">This case has been closed.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
