import { ArrowLeft, FileText, Search } from 'lucide-react';

interface StudentMenuProps {
  onChoice: (choice: 'new' | 'current') => void;
  onBack: () => void;
}

export function StudentMenu({ onChoice, onBack }: StudentMenuProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-2xl w-full">
        <button
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-center text-gray-900 mb-2">Welcome LC Saint</h2>
          <p className="text-center text-gray-600 mb-8">
            How can we help you today?
          </p>

          <div className="grid md:grid-cols-2 gap-6">
            <button
              onClick={() => onChoice('new')}
              className="p-8 border-2 border-gray-200 rounded-xl hover:border-indigo-500 hover:bg-indigo-50 transition-all group"
            >
              <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center group-hover:bg-indigo-200 transition-colors">
                  <FileText className="w-8 h-8 text-indigo-600" />
                </div>
                <span className="text-gray-900">Open a New Case</span>
              </div>
            </button>

            <button
              onClick={() => onChoice('current')}
              className="p-8 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all group"
            >
              <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center group-hover:bg-green-200 transition-colors">
                  <Search className="w-8 h-8 text-green-600" />
                </div>
                <span className="text-gray-900">View Current Case</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
